﻿//Written by Hamza Hameed and Jonah Mooradian

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class exitScript : MonoBehaviour {

	public void quit(){
		Application.Quit ();
	}
}
